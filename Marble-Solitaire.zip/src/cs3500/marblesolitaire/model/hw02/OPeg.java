package cs3500.marblesolitaire.model.hw02;
/**
 * represents the peg on the board. Specifically represents the peg in an "O".
 */

public class OPeg implements Peg {

  public String getPegState() {
    return "O";
  }

}

