package cs3500.marblesolitaire.model.hw02;
/**
 * represents a blank peg on the gameboard. This fills in the four corners in the game.
 */

public class BlankPeg implements Peg {

  public String getPegState() {
    return " ";
  }
}

