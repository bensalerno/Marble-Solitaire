package cs3500.marblesolitaire.model.hw02;

/**
 * Represents the peg in the center.
 */

public class CenterPeg implements Peg {

  public String getPegState() {
    return "_";
  }
}
